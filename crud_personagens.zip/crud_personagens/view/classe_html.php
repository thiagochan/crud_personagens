<?php

class ClasseHTML{
    public function desenharTabela($classes)
    {
        echo "<table class='table table-striped table-bordered'>";
        
        echo "<thead>";
        echo "<th scope='col'>Nome</th>";
        echo "<th scope='col'>Editar</th>";
        echo "<th scope='col'>Excluir</th>";
        echo "</thead>";

        echo "<tbody>";
        foreach($classes as $classe):
            echo "<tr>";
            echo "<td>".$classe->getNome()."</td>";
            echo "<td>"."<a href='../classes/altera_classe.php?id=".$classe->getIdClasse()."'>"."<img src='../imagens/editar.png'>"."</a>"."</td>";
            echo "<td>"."<a href='../classes/classe_deletar.php?id=".$classe->getIdClasse()."'>"."<img src='../imagens/excluir.png'>"."</a>"."</td>";
            echo "</tr>";
        endforeach;
        echo "</tbody>";

        echo "</table>";
    }
}
?>