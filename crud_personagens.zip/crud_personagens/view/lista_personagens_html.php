<?php
    class ListaPersonagensHTML {
        public static function desenharTabela($personagens)
        {
            echo "<table class='table table-striped table-bordered'>";

            echo "<thead>";
            echo "<th scope='col'>Nome</th>";
            echo "<th scope='col'>Idade</th>";
            echo "<th scope='col'>Classe</th>";
            echo "<th scope='col'>Descricao</th>";
            echo "<th scope='col'></th>";
            echo "<th scope='col'></th>";
            echo "</thead>";

            echo "<tbody>";

            foreach ($personagens as $personagem):
                echo "<tr>";
                echo "<td>".$personagem->getNome()."</td>";
                echo "<td>".$personagem->getIdade()."</td>";
                echo "<td>".$personagem->getClasse()->getNome()."</td>";
                echo "<td>".$personagem->getDescricao()."</td>";
                echo "<td>". "<a href='altera_personagem.php?id=".$personagem->getId()."'> Alterar </a>" ."</td>";
                echo "<td>". "<a href='personagem_deletar.php?id=".$personagem->getId()."'> Excluir </a>" ."</td>";
                echo "</tr>";
            endforeach;

            echo "</tbody>";

            echo "</table>";
        }
    }


?>