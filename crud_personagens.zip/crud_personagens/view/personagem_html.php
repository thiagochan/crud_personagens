<?php

class PersonagemHTML{
    public function desenhaSelect($classes, $name, $id, $idClasseSelec=0)
    {
        echo "<select class='form-control' name='".$name."' id='".$id."' >";

        foreach($classes as $classe):
            echo "<option value='".$classe->getIdClasse()."'";

            if ($classe->getIdClasse() == $idClasseSelec)
            {
                echo " selected";
            }

            echo "> ".$classe->getNome()."</option>";
        endforeach;

        echo "</select>";
    }
}

?>