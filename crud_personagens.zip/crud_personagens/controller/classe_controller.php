<?php

include_once("../dao/classe_dao.php");

class ClasseController {
    private $classeDAO;

    public function __construct() {
        $this->classeDAO = new ClasseDAO();
    }

    public function listar() {
        return $this->$classeDAO->list();
    }
}