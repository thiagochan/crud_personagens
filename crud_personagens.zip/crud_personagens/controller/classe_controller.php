<?php

include_once("../dao/classe_dao.php");
include_once("../model/classe.php");

class ClasseController {
    private $classeDAO;

    public function __construct() {
        $this->classeDAO = new ClasseDAO();
    }

    public function encontrarPorId($id)
    {
        return $this->classeDAO->findById($id);
    }

    public function listar() {
        return $this->classeDAO->list();
    }

    public function cadastrar($classe) 
    {
        return $this->classeDAO->create($classe);
    }

    public function excluir($classe)
    {
        return $this->classeDAO->delete($classe);
    }
}