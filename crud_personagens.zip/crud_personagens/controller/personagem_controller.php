<?php
include_once("../dao/personagem_dao.php");

class PersonagemController
{
    private $personagemDAO;

    public function __construct()
    {
        $this->personagemDAO = new PersonagemDAO();
    }

    public function encontrarPorId($id)
    {
        return $this->personagemDAO->findById($id);
    }

    public function cadastrar($personagem)
    {
        $this->personagemDAO->create($personagem);
    }

    public function listar()
    {
        return $this->personagemDAO->list();
    }

    public function alterar($personagem)
    {
        $this->personagemDAO->update($personagem);
    }

    public function deletar($personagem)
    {
        $this->personagemDAO->delete($personagem);
    }
}
?>