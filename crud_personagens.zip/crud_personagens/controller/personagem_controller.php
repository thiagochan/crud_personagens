<?php
include_once("../dao/personagem_dao.php");

class PersonagemController
{
    private $personagemDAO;

    public function __construct()
    {
        $this->personagemDAO = new PersonagemDAO();
    }

    public function cadastrar($personagem)
    {
        $this->personagemDAO->create($personagem);
    }
}
?>