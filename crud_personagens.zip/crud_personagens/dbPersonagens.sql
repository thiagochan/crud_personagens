
CREATE TABLE `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL,
  primary key (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `classes` (`id`, `nome`) VALUES
(1, 'mago'),
(2, 'guerreiro');

---------------------------------------------

CREATE TABLE `personagens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `idade` int(11) NOT NULL,
  `id_classe` int(11) NOT NULL,
  `descricao` text DEFAULT NULL,
  primary key (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Constraints for table `personagens`
--
ALTER TABLE `personagens`
  ADD CONSTRAINT `personagens_ibfk_1` FOREIGN KEY (`id_classe`) REFERENCES `classes` (`id`);

