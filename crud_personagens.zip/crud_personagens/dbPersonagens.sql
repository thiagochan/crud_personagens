
CREATE TABLE `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

INSERT INTO `classes` (`id`, `nome`) VALUES
(1, 'mago'),
(2, 'guerreiro');

---------------------------------------------

CREATE TABLE `personagens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `idade` int(11) NOT NULL,
  `id_classe` int(11) NOT NULL,
  `descricao` text DEFAULT NULL,
  `imagem` mediumblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


ALTER TABLE `personagens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_classe` (`id_classe`);
--
-- Constraints for table `personagens`
--
ALTER TABLE `personagens`
  ADD CONSTRAINT `personagens_ibfk_1` FOREIGN KEY (`id_classe`) REFERENCES `classes` (`id`);
COMMIT;

