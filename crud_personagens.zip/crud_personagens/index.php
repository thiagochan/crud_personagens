<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once("bootstrap/head.php"); ?>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <?php include_once("bootstrap/menu.php"); ?>

    <div class="container">
        <div class="row">
            <div class="col-6" id="personagens">
                <div class="card">
                    <img src="imagens/personagens.avif" class="card-img-top" alt="...">
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <a href="personagens/lista_personagens.php">
                                    Listar personagens
                                </a>
                            </li>
                            <li class="list-group-item">
                                <a href="personagens/cadastro_personagens.php">
                                    Cadastrar personagem
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-6" id="classes">
                <div class="card">
                    <img src="imagens/classes.webp" class="card-img-top" alt="...">
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <a href="classes/lista_classes.php">
                                    Listar classes 
                                </a>
                            </li>
                            <li class="list-group-item">
                                <a href="classes/cadastro_classes.php">
                                    Cadastrar classe
                                </a>
                            </li>
                        </ul>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include_once("bootstrap/footer.php"); ?>
</body>
</html>