<?php

echo '    <!-- Meta tags Obrigatórias -->';
echo '    <meta charset="utf-8">';
echo '    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">';

echo '    <!-- Bootstrap CSS -->';
echo '    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">';

echo '    <title>Cadastro de Personagens</title>';
?>