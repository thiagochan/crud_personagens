<?php
// Retirar /bootstrap/ da url
$project = dirname(__DIR__, 1);
// Retirar /opt/lampp/htdocs/ da url
$project = substr($project, 17);

echo '
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Home <span class="sr-only">(página
                atual)</span></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown"
                role="button" data-toggle="dropdown" aria-haspopup="true" aria-
                expanded="false">
                Cadastros
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="'.$project.'/personagens/cadastro_personagens.php">Personagens</a>
                    <a class="dropdown-item" href="'.$project.'/classes/cadastro_classes.php">Classes</a>
                </div>
            </li>
        </ul>
    </div>
</nav>

';
?>