<?php
$root = "/crud_personagens";

echo '
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="'.$root.'/index.php">Home <span class="sr-only">(página
                atual)</span></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown"
                role="button" data-toggle="dropdown" aria-haspopup="true" aria-
                expanded="false">
                Cadastros
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href='.$root.'/personagens/cadastro_personagens.php>Personagens</a>
                    <a class="dropdown-item" href='.$root.'/classes/cadastro_classes.php>Classes</a>
                </div>
            </li>
        </ul>
    </div>
</nav>

';
?>