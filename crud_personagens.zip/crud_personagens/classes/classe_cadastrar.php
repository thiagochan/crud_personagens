<?php

include_once("controller/classe_controller.php");

$classeController = new ClasseController();
$classeController->listar();