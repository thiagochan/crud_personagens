<?php

include_once("../controller/classe_controller.php");
include_once("../model/classe.php");

$nome = $_POST['nome_classe'];
$classe = new Classe();
$classe->setNome($nome);

$classeController = new ClasseController();
$classeController->cadastrar($classe);

header("location: ../index.php");