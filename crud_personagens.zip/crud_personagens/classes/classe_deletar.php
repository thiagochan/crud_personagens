<?php
    include_once("../controller/classe_controller.php");

    $idClasse = $_GET["id"];

    $classeCont = new ClasseController();
    $classe = $classeCont->encontrarPorId($idClasse);
    print_r($classe);
    
    if ($classe != null)
    {
        $classeCont->excluir($classe);

        header("location: ../classes/lista_classes.php");
    }
    else
    {
        echo "Classe com id ".$idClasse." não existe";
        echo "<br>";
        echo "<a href='../index.php'></a>";
    }
?>