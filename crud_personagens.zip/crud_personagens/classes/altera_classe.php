<?php
    include_once("../controller/classe_controller.php");
    
    $id = $_GET['id'];
    $classeCont = new ClasseController();
    $classe = $classeCont->encontrarPorId($id);

    if ($classe == null)
    {
        echo "Classe não encontrada";
        echo "<a href='lista_classes.php'>Voltar</a>";
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once("../bootstrap/head.php"); ?>
</head>
<body>
    <?php include_once("../bootstrap/menu.php"); ?>
    
    <h1 class="text-center">Alterar classes</h1>

    <form name="alteraClasse" method="POST" action="classe_alterar.php">
        <div class="form-group">
            <input class="form-control" type="text" id="nome" name="nome_classe"
             size="30" maxlength="20" placeholder="Informe o nome" value="<?php echo $classe->getNome(); ?>">
        </div>

        <input type="hidden" name="id_classe" value="<?php echo $classe->getIdClasse(); ?>">
        <button type="submit" class="btn">Enviar</button>
    </form>

    <?php include_once("../bootstrap/footer.php"); ?>
</body>
</html>