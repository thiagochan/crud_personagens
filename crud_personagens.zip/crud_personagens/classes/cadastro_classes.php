<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once("../bootstrap/head.php"); ?>
</head>
<body>
    <?php include_once("../bootstrap/menu.php"); ?>
    
    <h1 class="text-center">Cadastro de classes</h1>

    <form name="cadastroClasse" method="POST" action="classe_cadastrar.php">
        <div class="form-group">
            <input class="form-control" type="text" id="nome" name="nome_classe"
             size="30" maxlength="20" placeholder="Informe o nome">
        </div>
        <button type="submit" class="btn">Enviar</button>
    </form>

    <?php include_once("../bootstrap/footer.php"); ?>
</body>
</html>