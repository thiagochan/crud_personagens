<?php
    include_once("../controller/classe_controller.php");
    include_once("../view/classe_html.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once("../bootstrap/head.php"); ?>
</head>
<body>
    <?php include_once("../bootstrap/menu.php"); ?>
    <?php
        $classeCont = new ClasseController();
        $classes = $classeCont->listar();
        
        $classeHTML = new ClasseHTML();
        $classeHTML->desenharTabela($classes);

    ?>
    
    <?php include_once("../bootstrap/footer.php"); ?>
</body>
</html>