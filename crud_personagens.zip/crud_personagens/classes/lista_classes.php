<?php
    include_once("../controller/classe_controller.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once("../bootstrap/head.php"); ?>
</head>
<body>
    <?php include_once("../bootstrap/menu.php"); ?>
    <h1>qwejweqweqdsnfe</h1>
    <?php
        echo __DIR__;
        echo '<br>a';
        $classeCont = new ClasseController();
        $classes = $classeCont->listar();
        print_r($classes);
    ?>
    
    <?php include_once("../bootstrap/footer.php"); ?>
</body>
</html>