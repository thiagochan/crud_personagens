<?php
    include_once("../model/classe.php");
    include_once("../controller/classe_controller.php");

    $id = $_POST['id_classe'];
    $nome = $_POST['nome_classe'];

    $classe = new Classe($id, $nome);
    
    $classeCont = new ClasseController();
    $classeCont->alterar($classe);

    header("location: lista_classes.php");
?>