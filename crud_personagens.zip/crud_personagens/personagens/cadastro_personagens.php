<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once("../bootstrap/head.php"); ?>
</head>
<body>
    <?php include_once("../bootstrap/menu.php"); ?>
    <H1>cadastro personagens</H1>
    <?php include_once("../bootstrap/footer.php"); ?>
</body>
</html>