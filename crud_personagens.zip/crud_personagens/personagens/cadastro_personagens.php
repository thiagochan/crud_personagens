<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once("../bootstrap/head.php"); ?>
    <?php
        include_once("../controller/classe_controller.php");
        include_once("../view/personagem_html.php");
    ?>
</head>
<body>
    <?php include_once("../bootstrap/menu.php"); ?>
    <H1>cadastro personagens</H1>

    <form name="cadastroPersonagens" method="post" action="personagem_cadastrar.php">
        <div class="form-group">
            <label for="nomePersonagem">Nome:</label>
            <input class="form-control" type="text" id="nomePersonagem" name="nome_personagem"
            placeholder="Coloque o nome do personagem" size="30" maxlength="45">
        </div>
        <div class="form-group">
            <label for="idadePersonagem">Idade:</label>
            <input class="form-control" type="number" id="idadePersonagem" name="idade_personagem"
            placeholder="Coloque a idade do personagem" style="width: 100px">
        </div>
        <div class="form-group">
            <label for="classePersonagem">Classe:</label>
            <?php
                $classeCont = new ClasseController();
                $classes = $classeCont->listar();

                PersonagemHTML::desenhaSelect($classes, "classe_personagem", "classePersonagem");
            ?>
        </div>
        <div class="form-group">
            <label for="descricaoPersonagem">Descricao:</label>
            <input class="form-control" type="text" id="descricaoPersonagem" name="descricao_personagem"
            placeholder="Descreva o personagem ou escreva sua história" size="30" maxlength="65534">
        </div>

        <button type="submit" class="btn">Enviar</button>
    </form>
    <?php include_once("../bootstrap/footer.php"); ?>
</body>
</html>