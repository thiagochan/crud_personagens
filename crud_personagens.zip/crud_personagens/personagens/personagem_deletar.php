<?php
    include_once("../controller/personagem_controller.php");

    $id = $_GET["id"];

    $personagemCont = new PersonagemController();
    $personagem = $personagemCont->encontrarPorId($id);

    $personagemCont->deletar($personagem);

    header("location: lista_personagens.php");
?>