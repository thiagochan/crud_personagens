<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once("../bootstrap/head.php"); 
        include_once("../controller/personagem_controller.php");
        include_once("../view/lista_personagens_html.php");
    ?>
</head>
<body>
    <?php include_once("../bootstrap/menu.php"); ?>

    <h1>Listagem de personagens</h1>

    <?php
        $personagemCont = new PersonagemController();
        $personagens = $personagemCont->listar();

        //print_r($personagens);

        ListaPersonagensHTML::desenharTabela($personagens);
    ?>


    <?php include_once("../bootstrap/footer.php"); ?>
</body>
</html>