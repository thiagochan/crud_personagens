<?php
    include_once("../model/personagem.php");
    include_once("../model/classe.php");
    include_once("../controller/personagem_controller.php");

    $nome = $_POST['nome_personagem'];
    $idade = $_POST['idade_personagem'];
    $idClasse = $_POST['classe_personagem'];
    $descricao = $_POST['descricao_personagem'];

    $personagem = new Personagem();
    $personagem->setNome($nome);
    $personagem->setIdade($idade);
    
    $classe = new Classe($idClasse);
    $personagem->setClasse($classe);

    $personagem->setDescricao($descricao);
    
?>