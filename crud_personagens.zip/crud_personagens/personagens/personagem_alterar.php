<?php
    include_once("../controller/personagem_controller.php");
    include_once("../model/personagem.php");
    include_once("../model/classe.php");

    $id = $_POST['id_personagem'];
    $nome = $_POST['nome_personagem'];
    $idade = $_POST['idade_personagem'];
    $id_classe = $_POST['classe_personagem'];
    $descricao = $_POST['descricao_personagem'];

    $personagem = new Personagem();
    $personagem->setId($id);
    $personagem->setNome($nome);
    $personagem->setIdade($idade);
    
    $classe = new Classe($id_classe);
    $personagem->setClasse($classe);
    
    $personagem->setDescricao($descricao);

    $personagemCont = new PersonagemController();
    $personagemCont->alterar($personagem);

    header("location: lista_personagens.php");


?>