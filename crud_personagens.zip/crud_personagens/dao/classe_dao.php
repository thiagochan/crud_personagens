<?php

include_once("../util/conexao.php");
include_once("../model/classe.php");

class ClasseDAO {
    private const SQL_CLASSE = "SELECT * FROM classes c";

    private function mapClasses($resultSql)
    {
        $classes = array();

        foreach($resultSql as $reg):
            $classe = new Classe("", "");
            $classe->setIdClasse($reg['id']);
            $classe->setNome($reg['nome']);

            array_push($classes, $classe);
        endforeach;

        return $classes;
    }

    public function findById($id)
    {
        $conn = conectar_db();

        $sql = ClasseDAO::SQL_CLASSE . " WHERE c.id = ".$id;

        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        $classes = $this->mapClasses($result);

        if (count($classes) == 1)
        {
            return $classes[0];
        }
        elseif(count($classes) == 0)
        {
            return null;
        }

        die("ClasseDAO.findById - Erro: mais de uma classe".
                " encontrado para o ID ".$id);
    }

    public function list()
    {
        $conn = conectar_db();

        $sql = ClasseDAO::SQL_CLASSE. " ORDER BY c.nome";

        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        return $this->mapClasses($result);
    }

    public function create(Classe $classe)
    {
        $conn = conectar_db();

        $sql = "INSERT INTO classes (nome)".
                " VALUES (?)";

        $stm = $conn->prepare($sql);
        $stm->execute([$classe->getNome()]);
    }

    public function delete(Classe $classe)
    {
        $conn = conectar_db();
        $sql = "DELETE FROM classes WHERE id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$classe->getIdClasse()]);
    }

    public function update(Classe $classe)
    {
        $conn = conectar_db();
        $sql = "UPDATE classes SET nome = ? WHERE id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$classe->getNome(), $classe->getIdClasse()]);
    }
}