<?php

include_once("../util/conexao.php")
include_once("../model/classe.php");

class ClasseDAO {
    private const SQL_CLASSE = "SELECT * FROM classes c";

    private function mapClasses($resultSql)
    {
        $classes = array();

        foreach($resultSql as $reg):
            $classe = new Classe();
            $classe->setIdClasse($reg['id']);
            $classe->setNome($reg['nome']);

            array_push($classes, $classe);
        endforeach;

        return $classes;
    }

    public function list()
    {
        $conn = conectar_db();

        $sql = ClasseDAO::SQL_CLASSE. " ORDER BY c.nome";

        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        return $this->mapClasses($result);
    }
}