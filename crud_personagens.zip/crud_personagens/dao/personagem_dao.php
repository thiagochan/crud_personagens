<?php
include_once("../util/conexao.php");
include_once("../model/personagem.php");
include_once("../model/classe.php");

class PersonagemDAO
{
    private const SQL_PERSONAGEM = "SELECT p.*, c.nome AS nome_classe FROM personagens p".
                                    " JOIN classes c ON c.id = p.id_classe";
    
    private function mapPersonagens($resultSQL)
    {
        $personagens = array();
        
        foreach($resultSQL as $reg):
            $personagem = new Personagem();
            $personagem->setId($reg['id']);
            $personagem->setNome($reg['nome']);
            $personagem->setIdade($reg['idade']);

            $classe = new Classe($reg['id_classe'], $reg['nome_classe']);
            $personagem->setClasse($classe);

            $personagem->setDescricao($reg['descricao']);
            
            array_push($personagens, $personagem);
        endforeach;

        return $personagens;
    }

    public function findById($id)
    {
        $conn = conectar_db();

        $sql = PersonagemDAO::SQL_PERSONAGEM . " WHERE p.id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetchAll();

        $personagens =  $this->mapPersonagens($result);

        if (count($personagens) == 1)
        {
            return $personagens[0];
        }
        else if (count($personagens) == 0)
        {
            return null;
        }

        die("PersonagemDAO.findById - Encontrado mais de um personagem com o id ". $id);
    }

    public function list()
    {
        $conn = conectar_db();
        $sql = PersonagemDAO::SQL_PERSONAGEM . " ORDER BY p.nome";

        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        return $this->mapPersonagens($result);
    }

    public function create(Personagem $personagem)
    {
        $conn = conectar_db();

        $sql = "INSERT INTO personagens (nome, idade, id_classe, descricao)".
                " VALUES (?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$personagem->getNome(), $personagem->getIdade(), 
                        $personagem->getClasse()->getIdClasse(), $personagem->getDescricao()]);
    }

    public function update(Personagem $personagem)
    {
        $conn = conectar_db();
        
        $sql = "UPDATE personagens SET nome = ?, idade = ?, id_classe = ?, descricao = ? WHERE id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$personagem->getNome(), $personagem->getIdade(), $personagem->getClasse()->getIdClasse(), 
                        $personagem->getDescricao(), $personagem->getId()]);
    }

    public function delete(Personagem $personagem)
    {
        $conn = conectar_db();

        $sql = "DELETE FROM personagens WHERE id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$personagem->getId()]);
    }
}
?>