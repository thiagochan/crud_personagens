<?php
include_once("../util/conexao.php");
include_once("../model/personagem.php");

class PersonagemDAO
{
    private const SQL_PERSONAGEM = "SELECT p.*, c.nome AS nome_classe FROM personagens p".
                                    " JOIN classes c ON c.id = p.id_classe";
    
    public function create(Personagem $personagem)
    {
        $conn = conectar_db();

        $sql = "INSERT INTO personagens (nome, idade, id_classe, descricao)".
                " VALUES (?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$personagem->getNome(), $personagem->getIdade(), 
                        $personagem->getClasse()->getIdClasse(), $personagem->getDescricao()]);
    }
}
?>